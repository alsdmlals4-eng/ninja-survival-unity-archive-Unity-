using UnityEngine;

public class PlayerAutoMeleeWeapon : MonoBehaviour
{
    [Header("����")]
    [SerializeField] private PlayerMovement playerMovement;

    [Header("���� ����")]
    [SerializeField] private int damage = 1;
    [SerializeField] private float attackRange = 1.5f;
    [SerializeField] private float attackAngle = 45f;
    [SerializeField] private float attackCooldown = 0.8f;

    [Header("Ÿ�� ���")]
    [SerializeField] private LayerMask enemyLayer;

    [Header("���� ����")]
    [SerializeField] private bool attackOnlyWhenEnemyInRange = true;

    private float attackTimer;

    private void Awake()
    {
        if (playerMovement == null)
        {
            playerMovement = GetComponent<PlayerMovement>();
        }
    }

    private void Update()
    {
        if (playerMovement == null)
            return;

        if (playerMovement.IsDead)
            return;

        attackTimer -= Time.deltaTime;

        if (attackTimer > 0f)
            return;

        TryAutoAttack();
    }

    private void TryAutoAttack()
    {
        Collider2D[] enemiesInRange = FindEnemiesInAttackArea();

        if (attackOnlyWhenEnemyInRange && enemiesInRange.Length == 0)
            return;

        attackTimer = attackCooldown;

        playerMovement.PlayMelee();

        for (int i = 0; i < enemiesInRange.Length; i++)
        {
            EnemyHealth enemyHealth = enemiesInRange[i].GetComponentInParent<EnemyHealth>();

            if (enemyHealth == null)
                continue;

            enemyHealth.TakeDamage(damage);
        }
    }

    private Collider2D[] FindEnemiesInAttackArea()
    {
        Vector2 attackOrigin = transform.position;
        Vector2 lookDirection = playerMovement.LastLookDirection;

        if (lookDirection == Vector2.zero)
        {
            lookDirection = Vector2.down;
        }

        Collider2D[] hits = Physics2D.OverlapCircleAll(
            attackOrigin,
            attackRange,
            enemyLayer
        );

        int validCount = 0;

        for (int i = 0; i < hits.Length; i++)
        {
            Vector2 enemyPosition = hits[i].bounds.center;
            Vector2 directionToEnemy = enemyPosition - attackOrigin;

            if (directionToEnemy == Vector2.zero)
                continue;

            float angleToEnemy = Vector2.Angle(lookDirection, directionToEnemy);

            if (angleToEnemy <= attackAngle * 0.5f)
            {
                validCount++;
            }
            else
            {
                hits[i] = null;
            }
        }

        Collider2D[] validHits = new Collider2D[validCount];
        int index = 0;

        for (int i = 0; i < hits.Length; i++)
        {
            if (hits[i] == null)
                continue;

            validHits[index] = hits[i];
            index++;
        }

        return validHits;
    }

    public void IncreaseDamage(int amount)
    {
        damage += amount;
    }

    public void IncreaseRange(float amount)
    {
        attackRange += amount;
    }

    public void IncreaseAngle(float amount)
    {
        attackAngle += amount;
        attackAngle = Mathf.Clamp(attackAngle, 1f, 360f);
    }

    public void ReduceCooldown(float amount)
    {
        attackCooldown -= amount;
        attackCooldown = Mathf.Max(0.05f, attackCooldown);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}